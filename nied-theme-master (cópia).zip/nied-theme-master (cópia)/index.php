<div class="main">
  <img src="<?php echo get_template_directory_uri(); ?>/assets/images/main-img.png" alt="" srcset="">
  <div class="text">
    <p id="main-text-1">Bem vindo ao</p>
    <h2 id="main-text-2">Núcleo de Informática Aplicada à Educação</h2>
    <p id="main-text-3">A missão do NIED é difundir conhecimento sobre as relações entre a educação, a sociedade e a tecnologia por meio de pesquisas e desenvolvimento de tecnologias e metodologias de forma integrada às demandas da sociedade.</p>
  </div>
</div>


<?php
// Template Name: Notícias
get_header();
?>


<!-- noticias -->
<div class="container">
      <?php
         $args = array('category_name' => 'destaque', 'posts_per_page' => 1, 'post_status' => 'publish');
         $posts = get_posts($args);
         
         if($posts) : foreach ($posts as $post) : 
            the_title();
            the_excerpt();
      ?>
      <?php
         endforeach;
         endif;
      ?>
</div>
<?php get_footer(); ?>
